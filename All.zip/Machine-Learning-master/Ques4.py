import numpy as np

def createArrays():
    print("###### Arrays With all ones ##########")
    print(np.ones(shape=(5,4)))

    print("###### Arrays wiith all zeros ########")
    print(np.zeros(shape=(5,5)))
    
    print("####### Arrays with random values within range ########")
    
    print("Using Int values\n",np.random.randint(1,100,size=(5,5)))

    print("Using the float values\n",np.random.randn(5,5))

    print("######## A diagonal Matrix #######")
    
    data = [1,2,3,4,5]
    print(np.diag(v=data))
    
    
if __name__ == "__main__":
    createArrays()
