# creating and initializing integer variable
x = 5

# creating and initializing float variable
y = 3.14

# creating and initializing string variable
name = "John Doe"

# displaying integer variable
print(x)

# displaying float variable
print(y)

# displaying string variable
print(name)

# displaying simple string
print("Hello World!")

# using f-strings to format integer variable in string
print(f"The value of x is {x}")

# using f-strings to format float variable in string
print(f"The value of y is {y:.2f}")

# using f-strings to format string variable in string
print(f"My name is {name}")
