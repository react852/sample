import matplotlib.pyplot as plt
import numpy as np

# create data for all plots
x = np.linspace(0, 2*np.pi, 100)
y1 = np.sin(x)
y2 = np.cos(x)
labels = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J']

# create subplots
fig, axs = plt.subplots(2, 3, figsize=(12, 8))

# plot line graph
axs[0, 0].plot(x, y1, color='red', label='sin(x)')
axs[0, 0].plot(x, y2, color='blue', label='cos(x)')
axs[0, 0].set_xlabel('X-Axis')
axs[0, 0].set_ylabel('Y-Axis')
axs[0, 0].set_title('Line Graph')
axs[0, 0].legend()

# plot bar graph
axs[0, 1].bar(x, y1, color='red', alpha=0.5, label='sin(x)')
axs[0, 1].bar(x, y2, color='blue', alpha=0.5, label='cos(x)')
axs[0, 1].set_xlabel('X-Axis')
axs[0, 1].set_ylabel('Y-Axis')
axs[0, 1].set_title('Bar Graph')
axs[0, 1].legend()

# plot histogram
axs[0, 2].hist(y1, bins=10, color='red', alpha=0.5, label='sin(x)')
axs[0, 2].hist(y2, bins=10, color='blue', alpha=0.5, label='cos(x)')
axs[0, 2].set_xlabel('X-Axis')
axs[0, 2].set_ylabel('Y-Axis')
axs[0, 2].set_title('Histogram')
axs[0, 2].legend()

# plot pie chart
sizes = [np.abs(y1).sum(), np.abs(y2).sum()]
axs[1, 0].pie(sizes, labels=['sin(x)', 'cos(x)'], autopct='%1.1f%%')
axs[1, 0].set_title('Pie Chart')

# plot area plot
axs[1, 1].fill_between(x, y1, color='red', alpha=0.2, label='sin(x)')
axs[1, 1].fill_between(x, y2, color='blue', alpha=0.2, label='cos(x)')
axs[1, 1].set_xlabel('X-Axis')
axs[1, 1].set_ylabel('Y-Axis')
axs[1, 1].set_title('Area Plot')
axs[1, 1].legend()

# plot scatter plot
x2 = np.linspace(-np.pi/2, np.pi/2, 50)
y2 = np.random.uniform(-1, 1, 50)
axs[1, 2].scatter(x2, y2, color='red', marker='o')
axs[1, 2].set_xlabel('X-Axis')
axs[1, 2].set_ylabel('Y-Axis')
axs[1, 2].set_title('Scatter Plot of Random Data')

# adjust subplot layout
plt.tight_layout()

# show the plots
plt.show()
