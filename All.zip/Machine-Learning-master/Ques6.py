import numpy as np

def createMatrices():
    m1 = np.random.randint(20,50,size=(5,5))
    m2 = np.random.randint(20,50,size=(5,5))
    print("Matrix 1\n",m1,"\n\nMatrix 2\n",m2)

    print("\nAddition of Matrices\n",np.array(m1) + np.array(m2))
    print("\nSubtraction of Matrices\n", np.array(m1) - np.array(m2))
    print("\nMultiplication of Matrices\n",np.array(m1) * np.array(m2))
    
    row,col = int(input("\n\nEnter the row of the matrix ==> ")),int(input("Enter the column of the matrix ==> "))
    print(f"{row} Row of Matrix 1 ==> {m1[row]}\n")
    print(f"{row} Row of Matrix 2 ==> {m2[row]}\n")
    print(f"{col} Column of Matrix 1 : {m1[:,col]}\n")
    print(f"{col} Column of Matrix 2 : {m2[:,col]}\n")


if __name__ == "__main__":
    createMatrices()