# Example 1: Conditional Statement Function
def check_number(x):
    if x > 0:
        print("x is positive")
    elif x < 0:
        print("x is negative")
    else:
        print("x is zero")

# Output
check_number(5)


# Example 2: For Loop Function
def print_fruits(fruits):
    for fruit in fruits:
        print(fruit)

# Output
fruits = ["apple", "banana", "cherry"]
print_fruits(fruits)


# Example 3: While Loop Function
def print_numbers(n):
    i = 1
    while i < n:
        print(i)
        i += 1

# Output
print_numbers(6)
