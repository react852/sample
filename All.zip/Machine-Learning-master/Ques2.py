def logical_operations():
    a = bool(input("Enter the first Boolean value (True/False): "))
    b = bool(input("Enter the second Boolean value (True/False): "))

    # Logical AND
    print("Logical AND:", a and b)

    # Logical OR
    print("Logical OR:", a or b)

    # Logical NOT
    print("Logical NOT of a:", not a)
    print("Logical NOT of b:", not b)

    # Logical XOR
    print("Logical XOR:", a != b)


if __name__ == '__main__':
    logical_operations()
