import matplotlib.pyplot as plt
import numpy as np

# create data for all plots
x = np.linspace(0, 2*np.pi, 100)
y_sin = np.sin(x)
y_cos = np.cos(x)
y_matrix = np.random.rand(10, 10)

# create a line graph of sine and cosine functions
plt.plot(x, y_sin, color='red', label='Sine')
plt.plot(x, y_cos, color='blue', label='Cosine')
plt.xlabel('X-Axis')
plt.ylabel('Y-Axis')
plt.title('Line Graph of Sine and Cosine Functions')
plt.legend()
plt.show()

# create a bar graph of the mean values of the matrix columns
mean_vals = np.mean(y_matrix, axis=0)
plt.bar(range(len(mean_vals)), mean_vals)
plt.xlabel('Column Index')
plt.ylabel('Mean Value')
plt.title('Bar Graph of Mean Values of Matrix Columns')
plt.show()

# create a histogram of the values in the matrix
plt.hist(y_matrix.ravel(), bins=10)
plt.xlabel('Value')
plt.ylabel('Frequency')
plt.title('Histogram of Matrix Values')
plt.show()

# create a pie chart of the sum of the values in the matrix rows
sum_vals = np.sum(y_matrix, axis=1)
labels = [f'Row {i+1}' for i in range(len(sum_vals))]
plt.pie(sum_vals, labels=labels, autopct='%1.1f%%')
plt.title('Pie Chart of Sum of Matrix Row Values')
plt.show()

# create an area plot of the sine and cosine functions
plt.fill_between(x, y_sin, color='blue', alpha=0.2, label='Sine')
plt.fill_between(x, y_cos, color='red', alpha=0.2, label='Cosine')
plt.xlabel('X-Axis')
plt.ylabel('Y-Axis')
plt.title('Area Plot of Sine and Cosine Functions')
plt.legend()
plt.show()

# create a scatter plot of random values from the matrix
x_scatter = y_matrix.ravel()
y_scatter = np.random.rand(len(x_scatter))
plt.scatter(x_scatter, y_scatter, alpha=0.5)
plt.xlabel('Matrix Values')
plt.ylabel('Random Values')
plt.title('Scatter Plot of Matrix Values and Random Values')
plt.show()
