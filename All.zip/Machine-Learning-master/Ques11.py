import numpy as np

# Creating matrices
matrix1 = np.array([[1, 2], [3, 4]])
matrix2 = np.array([[5, 6], [7, 8]])

# Transpose of a matrix
transpose_matrix1 = np.transpose(matrix1)
print("Transpose of matrix1:\n", transpose_matrix1)

# Adding two matrices
add_matrix = matrix1 + matrix2
print("Addition of matrix1 and matrix2:\n", add_matrix)

# Subtracting two matrices
sub_matrix = matrix1 - matrix2
print("Subtraction of matrix1 and matrix2:\n", sub_matrix)

# Multiplying two matrices
mul_matrix = np.dot(matrix1, matrix2)
print("Multiplication of matrix1 and matrix2:\n", mul_matrix)
