def operate():
    a = float(input("Enter the first number: "))
    b = float(input("Enter the second number: "))
    operation = input("Enter the operation (+, *, /, **): ")

    if operation == "+":
        result = a + b
    elif operation == "*":
        result = a * b
    elif operation == "/":
        result = a / b
    elif operation == "**":
        result = a ** b
    else:
        print("Invalid operation")
        return

    print("Result: ", result)


if __name__ == '__main__':
    operate()
