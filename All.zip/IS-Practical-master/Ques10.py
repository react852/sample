import random
import string

# Generate a random monoalphabetic cipher key
alphabet = list(string.ascii_lowercase)
cipher_key = alphabet.copy()
random.shuffle(cipher_key)
cipher_key = ''.join(cipher_key)

# Define the plaintext and encrypt it using the cipher key
plaintext = "the quick brown fox jumps over the lazy dog"
ciphertext = ""
for letter in plaintext:
    if letter.isalpha():
        ciphertext += cipher_key[alphabet.index(letter.lower())]
    else:
        ciphertext += letter

print("Original plaintext:", plaintext)
print("Encrypted ciphertext:", ciphertext)
print("Cipher key:", cipher_key)

# Ciphertext-only attack
frequencies = {}
for letter in ciphertext:
    if letter.isalpha():
        if letter.lower() in frequencies:
            frequencies[letter.lower()] += 1
        else:
            frequencies[letter.lower()] = 1

sorted_frequencies = sorted(frequencies.items(), key=lambda x: x[1], reverse=True)
most_frequent = [x[0] for x in sorted_frequencies]
print("Most frequent letters in ciphertext:", most_frequent)

# Known-plaintext attack
known_plaintext = "the"
matching_pairs = []
for i in range(len(known_plaintext)):
    plaintext_letter = known_plaintext[i]
    ciphertext_letter = ciphertext[i]
    matching_pairs.append((plaintext_letter, ciphertext_letter))

matching_pairs = sorted(matching_pairs, key=lambda x: x[1])
matching_key = ""
for pair in matching_pairs:
    matching_key += alphabet[cipher_key.index(pair[1].lower())]

print("Matching pairs:", matching_pairs)
print("Matching key:", matching_key)
